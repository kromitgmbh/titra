(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var OAuth = Package.oauth.OAuth;
var Oauth = Package.oauth.Oauth;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var _ = Package.underscore._;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Cloudron;

var require = meteorInstall({"node_modules":{"meteor":{"faburem:cloudron":{"cloudron_server.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/faburem_cloudron/cloudron_server.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
'use strict'; /**                                                                                                      // 1
               * Define the base object namespace. By convention we use the service name                               //
               * in PascalCase (aka UpperCamelCase). Note that this is defined as a package global.                    //
               */                                                                                                      //
                                                                                                                       //
Cloudron = {};                                                                                                         // 7
                                                                                                                       //
if (process.env.OAUTH_CLIENT_ID && process.env.OAUTH_CLIENT_SECRET) {                                                  // 8
  ServiceConfiguration.configurations.update({                                                                         // 9
    service: 'cloudron'                                                                                                // 10
  }, {                                                                                                                 // 10
    $set: {                                                                                                            // 11
      client_id: process.env.OAUTH_CLIENT_ID,                                                                          // 13
      client_secret: process.env.OAUTH_CLIENT_SECRET                                                                   // 14
    }                                                                                                                  // 12
  }, {                                                                                                                 // 11
    upsert: true                                                                                                       // 17
  });                                                                                                                  // 17
}                                                                                                                      // 19
                                                                                                                       //
Meteor.settings.public.API_ORIGIN = process.env.API_ORIGIN;                                                            // 20
Meteor.settings.public.OAUTH_CLIENT_ID = process.env.OAUTH_CLIENT_ID; /**                                              // 21
                                                                       * Boilerplate hook for use by underlying Meteor code
                                                                       */                                              //
                                                                                                                       //
Cloudron.retrieveCredential = function (credentialToken, credentialSecret) {                                           // 25
  return OAuth.retrieveCredential(credentialToken, credentialSecret);                                                  // 26
};                                                                                                                     // 27
                                                                                                                       //
Cloudron.whitelistedFields = ['id', 'email', 'alternateEmail', 'username', 'displayName']; /**                         // 30
                                                                                            * Register this service with the underlying OAuth handler
                                                                                            * (name, oauthVersion, urls, handleOauthRequest):
                                                                                            *  name = 'cloudron'       //
                                                                                            *  oauthVersion = 2        //
                                                                                            *  urls = null for OAuth 2
                                                                                            *  handleOauthRequest = function(query) returns {serviceData, options} where options is optional
                                                                                            * serviceData will end up in the user's services.cloudron
                                                                                            */                         //
OAuth.registerService('cloudron', 2, null, function (query) {                                                          // 41
  /**                                                                                                                  // 43
   * Make sure we have a config object for subsequent use (boilerplate)                                                //
   */var config = ServiceConfiguration.configurations.findOne({                                                        //
    service: 'cloudron'                                                                                                // 47
  });                                                                                                                  // 46
                                                                                                                       //
  if (!config) {                                                                                                       // 49
    throw new ServiceConfiguration.ConfigError();                                                                      // 50
  } /**                                                                                                                // 51
     * Get the token and username (Meteor handles the underlying authorization flow).                                  //
     */                                                                                                                //
                                                                                                                       //
  var response = getTokens(config, query);                                                                             // 55
  var accessToken = response.accessToken; // const username = response.username;                                       // 56
  /**                                                                                                                  // 59
   * If we got here, we can now request data from the account endpoints                                                //
   * to complete our serviceData request.                                                                              //
   * The identity object will contain the username plus *all* properties                                               //
   * retrieved from the account and settings methods.                                                                  //
  */ // const identity = _.extend(                                                                                     //
  // {username},                                                                                                       // 66
                                                                                                                       //
  var identity = getAccount(config, accessToken); // getSettings(config, username, accessToken)                        // 67
  // );                                                                                                                // 69
  /**                                                                                                                  // 71
   * Build our serviceData object. This needs to contain                                                               //
   *  accessToken                                                                                                      //
   *  expiresAt, as a ms epochtime                                                                                     //
   *  refreshToken, if there is one                                                                                    //
   *  id - note that there *must* be an id property for Meteor to work with                                            //
   *  email                                                                                                            //
   *  reputation                                                                                                       //
   *  created                                                                                                          //
   * We'll put the username into the user's profile                                                                    //
   */                                                                                                                  //
  var serviceData = {                                                                                                  // 82
    accessToken: accessToken,                                                                                          // 83
    expiresAt: +new Date() + 6048 * 100000                                                                             // 84
  };                                                                                                                   // 82
                                                                                                                       //
  if (response.refreshToken) {                                                                                         // 86
    serviceData.refreshToken = response.refreshToken;                                                                  // 87
  }                                                                                                                    // 88
                                                                                                                       //
  _.extend(serviceData, _.pick(identity, Cloudron.whitelistedFields)); /**                                             // 89
                                                                        * Return the serviceData object along with an options object containing
                                                                        * the initial profile object with the username.
                                                                        */                                             //
                                                                                                                       //
  return {                                                                                                             // 95
    serviceData: serviceData,                                                                                          // 96
    options: {                                                                                                         // 97
      profile: {                                                                                                       // 98
        name: identity.displayName,                                                                                    // 99
        username: identity.username                                                                                    // 100
      }                                                                                                                // 98
    }                                                                                                                  // 97
  };                                                                                                                   // 95
}); /**                                                                                                                // 104
     * The following three utility functions are called in the above code to get                                       //
     *  the access_token                                                                                               //
     *  account data (getAccount)                                                                                      //
     * repectively.                                                                                                    //
     */ /** getTokens exchanges a code for a token                                                                     //
         *                                                                                                             //
         *  returns an object containing:                                                                              //
         *   accessToken        {String}                                                                               //
         *                                                                                                             //
         * @param   {Object} config       The OAuth configuration object                                               //
         * @param   {Object} query        The OAuth query object                                                       //
         * @return  {Object}              The response from the token request (see above)                              //
         */                                                                                                            //
                                                                                                                       //
var getTokens = function (config, query) {                                                                             // 122
  var endpoint = process.env.API_ORIGIN + '/api/v1/oauth/token'; /**                                                   // 124
                                                                  * Attempt the exchange of code for token             //
                                                                  */                                                   //
  var response = void 0;                                                                                               // 129
                                                                                                                       //
  try {                                                                                                                // 130
    response = HTTP.post(endpoint, {                                                                                   // 131
      params: {                                                                                                        // 133
        code: query.code,                                                                                              // 134
        client_id: process.env.OAUTH_CLIENT_ID,                                                                        // 135
        client_secret: process.env.OAUTH_CLIENT_SECRET,                                                                // 136
        grant_type: 'authorization_code'                                                                               // 137
      }                                                                                                                // 133
    });                                                                                                                // 132
  } catch (err) {                                                                                                      // 141
    throw _.extend(new Error("Failed to complete OAuth handshake with Cloudron. " + err.message), {                    // 142
      response: err.response                                                                                           // 143
    });                                                                                                                // 142
  }                                                                                                                    // 145
                                                                                                                       //
  if (response.data.error) {                                                                                           // 146
    /**                                                                                                                // 148
     * The http response was a json object with an error attribute                                                     //
     */throw new Error("Failed to complete OAuth handshake with Cloudron. " + response.data.error);                    //
  } else {                                                                                                             // 153
    /** The exchange worked. We have an object containing                                                              // 155
     *   access_token                                                                                                  //
     *                                                                                                                 //
     * Return an appropriately constructed object                                                                      //
     */return {                                                                                                        //
      accessToken: response.data.access_token                                                                          // 161
    };                                                                                                                 // 160
  }                                                                                                                    // 163
}; /**                                                                                                                 // 164
    * getAccount gets the basic Cloudron account data                                                                  //
    *                                                                                                                  //
    *  returns an object containing:                                                                                   //
    *   id             {Integer}         The user's Cloudron id                                                        //
    *   url            {String}          The account username as requested in the URI                                  //
    *   bio            {String}          A basic description the user has filled out                                   //
    *   reputation     {Float}           The reputation for the account.                                               //
    *   created        {Integer}         The epoch time of account creation                                            //
    *   pro_expiration {Integer/Boolean} False if not a pro user, their expiration date if they are.                   //
    *                                                                                                                  //
    * @param   {Object} config       The OAuth configuration object                                                    //
    * @param   {String} accessToken  The OAuth access token                                                            //
    * @return  {Object}              The response from the account request (see above)                                 //
    */                                                                                                                 //
                                                                                                                       //
var getAccount = function (config, accessToken) {                                                                      // 181
  var endpoint = process.env.API_ORIGIN + "/api/v1/profile";                                                           // 183
  var accountObject = void 0;                                                                                          // 184
                                                                                                                       //
  try {                                                                                                                // 186
    accountObject = HTTP.get(endpoint, {                                                                               // 187
      headers: {                                                                                                       // 189
        Authorization: "Bearer " + accessToken                                                                         // 190
      }                                                                                                                // 189
    }).data;                                                                                                           // 188
    return accountObject;                                                                                              // 194
  } catch (err) {                                                                                                      // 196
    throw _.extend(new Error("Failed to fetch account data from Cloudron. " + err.message), {                          // 197
      response: err.response                                                                                           // 198
    });                                                                                                                // 197
  }                                                                                                                    // 200
};                                                                                                                     // 201
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/faburem:cloudron/cloudron_server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['faburem:cloudron'] = {}, {
  Cloudron: Cloudron
});

})();

//# sourceMappingURL=faburem_cloudron.js.map
