(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var Random = Package.random.Random;
var Accounts = Package['accounts-base'].Accounts;
var Cloudron = Package['faburem:cloudron'].Cloudron;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"faburem:accounts-cloudron":{"accounts-cloudron.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/faburem_accounts-cloudron/accounts-cloudron.js                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
'use strict'; /**                                                                                                    // 1
               * Register this service (boilerplate).                                                                //
               */                                                                                                    //
                                                                                                                     //
Accounts.oauth.registerService('cloudron'); /**                                                                      // 6
                                             * Client functionality (boilerplate).                                   //
                                             */                                                                      //
                                                                                                                     //
if (Meteor.isClient) {                                                                                               // 11
  Meteor.loginWithCloudron = function (options, callback) {                                                          // 12
    /**                                                                                                              // 14
     * support (options, callback) and (callback)                                                                    //
     */if (!callback && typeof options === "function") {                                                             //
      callback = options;                                                                                            // 18
      options = null;                                                                                                // 19
    } /**                                                                                                            // 20
       *                                                                                                             //
       */                                                                                                            //
                                                                                                                     //
    var credentialRequestCompleteCallback = Accounts.oauth.credentialRequestCompleteHandler(callback);               // 25
    Cloudron.requestCredential(options, credentialRequestCompleteCallback);                                          // 26
  }; /**                                                                                                             // 27
      * Server functionality (boilerplate).                                                                          //
      * Ensures sanity of published user object.                                                                     //
      */                                                                                                             //
} else {                                                                                                             // 33
  Accounts.addAutopublishFields({                                                                                    // 34
    forLoggedInUser: _.map( /**                                                                                      // 35
                             * Logged in user gets whitelisted fields + accessToken + expiresAt.                     //
                             */Cloudron.whitelistedFields.concat(['accessToken', 'expiresAt']), // don't publish refresh token
    function (subfield) {                                                                                            // 40
      return 'services.cloudron.' + subfield;                                                                        // 41
    }),                                                                                                              // 42
    forOtherUsers: _.map( /**                                                                                        // 44
                           * Other users get whitelisted fields without emails, because even with                    //
                           * autopublish, no legitimate web app should be publishing all users' emails.              //
                           */_.without(Cloudron.whitelistedFields, 'email', 'verified_email'), function (subfield) {
      return 'services.cloudron.' + subfield;                                                                        // 51
    })                                                                                                               // 52
  });                                                                                                                // 34
}                                                                                                                    // 54
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/faburem:accounts-cloudron/accounts-cloudron.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['faburem:accounts-cloudron'] = {};

})();

//# sourceMappingURL=faburem_accounts-cloudron.js.map
