var require = meteorInstall({"imports":{"api":{"projects":{"server":{"publications.js":["moment","meteor/check","../projects","../../timecards/timecards.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/projects/server/publications.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var moment = void 0;                                                                                                   // 1
module.importSync("moment", {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    moment = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var check = void 0;                                                                                                    // 1
module.importSync("meteor/check", {                                                                                    // 1
  check: function (v) {                                                                                                // 1
    check = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Projects = void 0;                                                                                                 // 1
module.importSync("../projects", {                                                                                     // 1
  "default": function (v) {                                                                                            // 1
    Projects = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Timecards = void 0;                                                                                                // 1
module.importSync("../../timecards/timecards.js", {                                                                    // 1
  "default": function (v) {                                                                                            // 1
    Timecards = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
Meteor.publish('myprojects', function () {                                                                             // 6
  function myProjects() {                                                                                              // 6
    if (!this.userId) {                                                                                                // 7
      return this.ready();                                                                                             // 8
    }                                                                                                                  // 9
                                                                                                                       //
    return Projects.find({                                                                                             // 10
      $or: [{                                                                                                          // 10
        userId: this.userId                                                                                            // 10
      }, {                                                                                                             // 10
        "public": true                                                                                                 // 10
      }]                                                                                                               // 10
    });                                                                                                                // 10
  }                                                                                                                    // 11
                                                                                                                       //
  return myProjects;                                                                                                   // 6
}());                                                                                                                  // 6
Meteor.publish('singleProject', function () {                                                                          // 12
  function singleProject(projectId) {                                                                                  // 12
    check(projectId, String);                                                                                          // 13
                                                                                                                       //
    if (!this.userId) {                                                                                                // 14
      return this.ready();                                                                                             // 15
    }                                                                                                                  // 16
                                                                                                                       //
    return Projects.find({                                                                                             // 17
      $or: [{                                                                                                          // 17
        userId: this.userId                                                                                            // 17
      }, {                                                                                                             // 17
        "public": true                                                                                                 // 17
      }],                                                                                                              // 17
      _id: projectId                                                                                                   // 17
    });                                                                                                                // 17
  }                                                                                                                    // 18
                                                                                                                       //
  return singleProject;                                                                                                // 12
}());                                                                                                                  // 12
Meteor.publish('myProjectStats', function () {                                                                         // 20
  function myProjectStats() {                                                                                          // 20
    var _this = this;                                                                                                  // 20
                                                                                                                       //
    var initializing = true;                                                                                           // 21
    var currentMonthStart = moment().startOf('month');                                                                 // 23
    var currentMonthEnd = moment().endOf('month');                                                                     // 24
    var previousMonthStart = moment().startOf('month');                                                                // 25
    var previousMonthEnd = moment().endOf('month'); // observeChanges only returns after the initial `added` callbacks
    // have run. Until then, we don't want to send a lot of                                                            // 28
    // `self.changed()` messages - hence tracking the                                                                  // 29
    // `initializing` state.                                                                                           // 30
                                                                                                                       //
    var handle = Projects.find({                                                                                       // 31
      $or: [{                                                                                                          // 31
        userId: this.userId                                                                                            // 31
      }, {                                                                                                             // 31
        "public": true                                                                                                 // 32
      }]                                                                                                               // 32
    }).observeChanges({                                                                                                // 31
      added: function (projectId) {                                                                                    // 33
        if (!initializing) {                                                                                           // 34
          var totalHours = 0;                                                                                          // 35
          var currentMonthHours = 0;                                                                                   // 36
          var previousMonthHours = 0;                                                                                  // 37
                                                                                                                       //
          for (var _iterator = Timecards.find({                                                                        // 38
            userId: _this.userId,                                                                                      // 39
            projectId: projectId                                                                                       // 39
          }).fetch(), _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
            var _ref;                                                                                                  // 39
                                                                                                                       //
            if (_isArray) {                                                                                            // 39
              if (_i >= _iterator.length) break;                                                                       // 39
              _ref = _iterator[_i++];                                                                                  // 39
            } else {                                                                                                   // 39
              _i = _iterator.next();                                                                                   // 39
              if (_i.done) break;                                                                                      // 39
              _ref = _i.value;                                                                                         // 39
            }                                                                                                          // 39
                                                                                                                       //
            var timecard = _ref;                                                                                       // 39
                                                                                                                       //
            if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                       // 40
              currentMonthHours += Number.parseFloat(timecard.hours);                                                  // 41
            }                                                                                                          // 42
                                                                                                                       //
            if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                     // 43
              previousMonthHours += Number.parseFloat(timecard.hours);                                                 // 44
            }                                                                                                          // 45
                                                                                                                       //
            totalHours += Number.parseFloat(timecard.hours);                                                           // 46
          }                                                                                                            // 47
                                                                                                                       //
          _this.changed('projectStats', projectId, {                                                                   // 48
            totalHours: totalHours,                                                                                    // 48
            currentMonthHours: currentMonthHours,                                                                      // 48
            previousMonthHours: previousMonthHours                                                                     // 48
          });                                                                                                          // 48
        }                                                                                                              // 49
      },                                                                                                               // 50
      removed: function (projectId) {                                                                                  // 51
        var totalHours = 0;                                                                                            // 52
        var currentMonthHours = 0;                                                                                     // 53
        var previousMonthHours = 0;                                                                                    // 54
                                                                                                                       //
        for (var _iterator2 = Timecards.find({                                                                         // 55
          userId: _this.userId,                                                                                        // 56
          projectId: projectId                                                                                         // 56
        }).fetch(), _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
          var _ref2;                                                                                                   // 56
                                                                                                                       //
          if (_isArray2) {                                                                                             // 56
            if (_i2 >= _iterator2.length) break;                                                                       // 56
            _ref2 = _iterator2[_i2++];                                                                                 // 56
          } else {                                                                                                     // 56
            _i2 = _iterator2.next();                                                                                   // 56
            if (_i2.done) break;                                                                                       // 56
            _ref2 = _i2.value;                                                                                         // 56
          }                                                                                                            // 56
                                                                                                                       //
          var timecard = _ref2;                                                                                        // 56
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                         // 57
            currentMonthHours += Number.parseFloat(timecard.hours);                                                    // 58
          }                                                                                                            // 59
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                       // 60
            previousMonthHours += Number.parseFloat(timecard.hours);                                                   // 61
          }                                                                                                            // 62
                                                                                                                       //
          totalHours += Number.parseFloat(timecard.hours);                                                             // 63
        }                                                                                                              // 64
                                                                                                                       //
        _this.changed('projectStats', projectId, {                                                                     // 65
          totalHours: totalHours,                                                                                      // 65
          currentMonthHours: currentMonthHours,                                                                        // 65
          previousMonthHours: previousMonthHours                                                                       // 65
        });                                                                                                            // 65
      },                                                                                                               // 66
      changed: function (projectId) {                                                                                  // 67
        var totalHours = 0;                                                                                            // 68
        var currentMonthHours = 0;                                                                                     // 69
        var previousMonthHours = 0;                                                                                    // 70
                                                                                                                       //
        for (var _iterator3 = Timecards.find({                                                                         // 71
          userId: _this.userId,                                                                                        // 72
          projectId: projectId                                                                                         // 72
        }).fetch(), _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
          var _ref3;                                                                                                   // 72
                                                                                                                       //
          if (_isArray3) {                                                                                             // 72
            if (_i3 >= _iterator3.length) break;                                                                       // 72
            _ref3 = _iterator3[_i3++];                                                                                 // 72
          } else {                                                                                                     // 72
            _i3 = _iterator3.next();                                                                                   // 72
            if (_i3.done) break;                                                                                       // 72
            _ref3 = _i3.value;                                                                                         // 72
          }                                                                                                            // 72
                                                                                                                       //
          var timecard = _ref3;                                                                                        // 72
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                         // 73
            currentMonthHours += Number.parseFloat(timecard.hours);                                                    // 74
          }                                                                                                            // 75
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                       // 76
            previousMonthHours += Number.parseFloat(timecard.hours);                                                   // 77
          }                                                                                                            // 78
                                                                                                                       //
          totalHours += Number.parseFloat(timecard.hours);                                                             // 79
        }                                                                                                              // 80
                                                                                                                       //
        _this.changed('projectStats', projectId, {                                                                     // 81
          totalHours: totalHours,                                                                                      // 81
          currentMonthHours: currentMonthHours,                                                                        // 81
          previousMonthHours: previousMonthHours                                                                       // 81
        });                                                                                                            // 81
      }                                                                                                                // 82
    }); // Instead, we'll send one `self.added()` message right after                                                  // 32
    // observeChanges has returned, and mark the subscription as                                                       // 85
    // ready.                                                                                                          // 86
                                                                                                                       //
    initializing = false;                                                                                              // 87
                                                                                                                       //
    for (var _iterator4 = Projects.find({                                                                              // 88
      $or: [{                                                                                                          // 88
        userId: this.userId                                                                                            // 88
      }, {                                                                                                             // 88
        "public": true                                                                                                 // 89
      }]                                                                                                               // 89
    }).fetch(), _isArray4 = Array.isArray(_iterator4), _i4 = 0, _iterator4 = _isArray4 ? _iterator4 : _iterator4[Symbol.iterator]();;) {
      var _ref4;                                                                                                       // 89
                                                                                                                       //
      if (_isArray4) {                                                                                                 // 89
        if (_i4 >= _iterator4.length) break;                                                                           // 89
        _ref4 = _iterator4[_i4++];                                                                                     // 89
      } else {                                                                                                         // 89
        _i4 = _iterator4.next();                                                                                       // 89
        if (_i4.done) break;                                                                                           // 89
        _ref4 = _i4.value;                                                                                             // 89
      }                                                                                                                // 89
                                                                                                                       //
      var project = _ref4;                                                                                             // 89
      var totalHours = 0;                                                                                              // 90
      var currentMonthHours = 0;                                                                                       // 91
      var previousMonthHours = 0;                                                                                      // 92
                                                                                                                       //
      for (var _iterator5 = Timecards.find({                                                                           // 93
        userId: this.userId,                                                                                           // 94
        projectId: project._id                                                                                         // 94
      }).fetch(), _isArray5 = Array.isArray(_iterator5), _i5 = 0, _iterator5 = _isArray5 ? _iterator5 : _iterator5[Symbol.iterator]();;) {
        var _ref5;                                                                                                     // 94
                                                                                                                       //
        if (_isArray5) {                                                                                               // 94
          if (_i5 >= _iterator5.length) break;                                                                         // 94
          _ref5 = _iterator5[_i5++];                                                                                   // 94
        } else {                                                                                                       // 94
          _i5 = _iterator5.next();                                                                                     // 94
          if (_i5.done) break;                                                                                         // 94
          _ref5 = _i5.value;                                                                                           // 94
        }                                                                                                              // 94
                                                                                                                       //
        var timecard = _ref5;                                                                                          // 94
                                                                                                                       //
        if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                           // 95
          currentMonthHours += Number.parseFloat(timecard.hours);                                                      // 96
        }                                                                                                              // 97
                                                                                                                       //
        if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                         // 98
          previousMonthHours += Number.parseFloat(timecard.hours);                                                     // 99
        }                                                                                                              // 100
                                                                                                                       //
        totalHours += Number.parseFloat(timecard.hours);                                                               // 101
      }                                                                                                                // 102
                                                                                                                       //
      this.added('projectStats', project._id, {                                                                        // 103
        totalHours: totalHours,                                                                                        // 103
        currentMonthHours: currentMonthHours,                                                                          // 103
        previousMonthHours: previousMonthHours                                                                         // 103
      });                                                                                                              // 103
    }                                                                                                                  // 104
                                                                                                                       //
    this.ready(); // Stop observing the cursor when client unsubs.                                                     // 105
    // Stopping a subscription automatically takes                                                                     // 107
    // care of sending the client any removed messages.                                                                // 108
                                                                                                                       //
    this.onStop(function () {                                                                                          // 109
      handle.stop();                                                                                                   // 110
    });                                                                                                                // 111
  }                                                                                                                    // 112
                                                                                                                       //
  return myProjectStats;                                                                                               // 20
}());                                                                                                                  // 20
Meteor.publish('projectStats', function () {                                                                           // 114
  function projectStats(projectId) {                                                                                   // 114
    var _this2 = this;                                                                                                 // 114
                                                                                                                       //
    check(projectId, String);                                                                                          // 115
                                                                                                                       //
    if (!this.userId || !Projects.findOne({                                                                            // 116
      _id: projectId,                                                                                                  // 116
      $or: [{                                                                                                          // 117
        userId: this.userId                                                                                            // 117
      }, {                                                                                                             // 117
        "public": true                                                                                                 // 117
      }]                                                                                                               // 117
    })) {                                                                                                              // 116
      return this.ready();                                                                                             // 118
    }                                                                                                                  // 119
                                                                                                                       //
    var initializing = true;                                                                                           // 120
    var currentMonthName = moment().format('MMM');                                                                     // 121
    var currentMonthStart = moment().startOf('month');                                                                 // 122
    var currentMonthEnd = moment().endOf('month');                                                                     // 123
    var previousMonthName = moment().subtract('1', 'months').format('MMM');                                            // 124
    var previousMonthStart = moment().subtract('1', 'months').startOf('month');                                        // 125
    var previousMonthEnd = moment().subtract('1', 'months').endOf('month');                                            // 126
    var beforePreviousMonthStart = moment().subtract('2', 'months').startOf('month');                                  // 127
    var beforePreviousMonthEnd = moment().subtract('2', 'months').endOf('month');                                      // 128
    var beforePreviousMonthName = moment().subtract('2', 'months').format('MMM');                                      // 129
    var totalHours = 0;                                                                                                // 131
    var currentMonthHours = 0;                                                                                         // 132
    var previousMonthHours = 0;                                                                                        // 133
    var beforePreviousMonthHours = 0; // observeChanges only returns after the initial `added` callbacks               // 134
    // have run. Until then, we don't want to send a lot of                                                            // 137
    // `self.changed()` messages - hence tracking the                                                                  // 138
    // `initializing` state.                                                                                           // 139
                                                                                                                       //
    var handle = Timecards.find({                                                                                      // 140
      projectId: projectId                                                                                             // 140
    }).observeChanges({                                                                                                // 140
      added: function (timecardId) {                                                                                   // 141
        if (!initializing) {                                                                                           // 142
          var timecard = Timecards.findOne({                                                                           // 143
            _id: timecardId                                                                                            // 143
          });                                                                                                          // 143
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                         // 144
            currentMonthHours += Number.parseFloat(timecard.hours);                                                    // 145
          }                                                                                                            // 146
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                       // 147
            previousMonthHours += Number.parseFloat(timecard.hours);                                                   // 148
          }                                                                                                            // 149
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(beforePreviousMonthStart, beforePreviousMonthEnd)) {           // 150
            beforePreviousMonthHours += Number.parseFloat(timecard.hours);                                             // 152
          }                                                                                                            // 153
                                                                                                                       //
          totalHours += Number.parseFloat(timecard.hours);                                                             // 154
                                                                                                                       //
          _this2.changed('projectStats', projectId, {                                                                  // 155
            totalHours: totalHours,                                                                                    // 155
            currentMonthName: currentMonthName,                                                                        // 155
            currentMonthHours: currentMonthHours,                                                                      // 155
            previousMonthHours: previousMonthHours,                                                                    // 155
            previousMonthName: previousMonthName,                                                                      // 155
            beforePreviousMonthName: beforePreviousMonthName,                                                          // 155
            beforePreviousMonthHours: beforePreviousMonthHours                                                         // 155
          });                                                                                                          // 155
        }                                                                                                              // 156
      },                                                                                                               // 157
      removed: function (timecardId) {                                                                                 // 158
        if (!initializing) {                                                                                           // 159
          var timecard = Timecards.findOne({                                                                           // 160
            _id: timecardId                                                                                            // 160
          });                                                                                                          // 160
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                         // 161
            currentMonthHours += Number.parseFloat(timecard.hours);                                                    // 162
          }                                                                                                            // 163
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                       // 164
            previousMonthHours += Number.parseFloat(timecard.hours);                                                   // 165
          }                                                                                                            // 166
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(beforePreviousMonthStart, beforePreviousMonthEnd)) {           // 167
            beforePreviousMonthHours += Number.parseFloat(timecard.hours);                                             // 169
          }                                                                                                            // 170
                                                                                                                       //
          totalHours += Number.parseFloat(timecard.hours);                                                             // 171
                                                                                                                       //
          _this2.changed('projectStats', projectId, {                                                                  // 172
            totalHours: totalHours,                                                                                    // 172
            currentMonthName: currentMonthName,                                                                        // 172
            currentMonthHours: currentMonthHours,                                                                      // 172
            previousMonthHours: previousMonthHours,                                                                    // 172
            previousMonthName: previousMonthName,                                                                      // 172
            beforePreviousMonthName: beforePreviousMonthName,                                                          // 172
            beforePreviousMonthHours: beforePreviousMonthHours                                                         // 172
          });                                                                                                          // 172
        }                                                                                                              // 173
      },                                                                                                               // 174
      changed: function (timecardId) {                                                                                 // 175
        if (!initializing) {                                                                                           // 176
          var timecard = Timecards.findOne({                                                                           // 177
            _id: timecardId                                                                                            // 177
          });                                                                                                          // 177
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                         // 178
            currentMonthHours += Number.parseFloat(timecard.hours);                                                    // 179
          }                                                                                                            // 180
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                       // 181
            previousMonthHours += Number.parseFloat(timecard.hours);                                                   // 182
          }                                                                                                            // 183
                                                                                                                       //
          if (moment(new Date(timecard.date)).isBetween(beforePreviousMonthStart, beforePreviousMonthEnd)) {           // 184
            beforePreviousMonthHours += Number.parseFloat(timecard.hours);                                             // 186
          }                                                                                                            // 187
                                                                                                                       //
          totalHours += Number.parseFloat(timecard.hours);                                                             // 188
                                                                                                                       //
          _this2.changed('projectStats', projectId, {                                                                  // 189
            totalHours: totalHours,                                                                                    // 189
            currentMonthName: currentMonthName,                                                                        // 189
            currentMonthHours: currentMonthHours,                                                                      // 189
            previousMonthHours: previousMonthHours,                                                                    // 189
            previousMonthName: previousMonthName,                                                                      // 189
            beforePreviousMonthName: beforePreviousMonthName,                                                          // 189
            beforePreviousMonthHours: beforePreviousMonthHours                                                         // 189
          });                                                                                                          // 189
        }                                                                                                              // 190
      }                                                                                                                // 191
    }); // Instead, we'll send one `self.added()` message right after                                                  // 140
    // observeChanges has returned, and mark the subscription as                                                       // 194
    // ready.                                                                                                          // 195
                                                                                                                       //
    initializing = false;                                                                                              // 196
                                                                                                                       //
    for (var _iterator6 = Timecards.find({                                                                             // 197
      projectId: projectId                                                                                             // 198
    }).fetch(), _isArray6 = Array.isArray(_iterator6), _i6 = 0, _iterator6 = _isArray6 ? _iterator6 : _iterator6[Symbol.iterator]();;) {
      var _ref6;                                                                                                       // 198
                                                                                                                       //
      if (_isArray6) {                                                                                                 // 198
        if (_i6 >= _iterator6.length) break;                                                                           // 198
        _ref6 = _iterator6[_i6++];                                                                                     // 198
      } else {                                                                                                         // 198
        _i6 = _iterator6.next();                                                                                       // 198
        if (_i6.done) break;                                                                                           // 198
        _ref6 = _i6.value;                                                                                             // 198
      }                                                                                                                // 198
                                                                                                                       //
      var timecard = _ref6;                                                                                            // 198
                                                                                                                       //
      if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                             // 199
        currentMonthHours += Number.parseFloat(timecard.hours);                                                        // 200
      }                                                                                                                // 201
                                                                                                                       //
      if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                           // 202
        previousMonthHours += Number.parseFloat(timecard.hours);                                                       // 203
      }                                                                                                                // 204
                                                                                                                       //
      if (moment(new Date(timecard.date)).isBetween(beforePreviousMonthStart, beforePreviousMonthEnd)) {               // 205
        beforePreviousMonthHours += Number.parseFloat(timecard.hours);                                                 // 207
      }                                                                                                                // 208
                                                                                                                       //
      totalHours += Number.parseFloat(timecard.hours);                                                                 // 209
    }                                                                                                                  // 210
                                                                                                                       //
    this.added('projectStats', projectId, {                                                                            // 211
      totalHours: totalHours,                                                                                          // 211
      currentMonthName: currentMonthName,                                                                              // 211
      currentMonthHours: currentMonthHours,                                                                            // 211
      previousMonthHours: previousMonthHours,                                                                          // 211
      previousMonthName: previousMonthName,                                                                            // 211
      beforePreviousMonthName: beforePreviousMonthName,                                                                // 211
      beforePreviousMonthHours: beforePreviousMonthHours                                                               // 211
    }); // Stop observing the cursor when client unsubs.                                                               // 211
    // Stopping a subscription automatically takes                                                                     // 213
    // care of sending the client any removed messages.                                                                // 214
                                                                                                                       //
    this.onStop(function () {                                                                                          // 215
      handle.stop();                                                                                                   // 216
    });                                                                                                                // 217
    return this.ready();                                                                                               // 218
  }                                                                                                                    // 219
                                                                                                                       //
  return projectStats;                                                                                                 // 114
}());                                                                                                                  // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["moment","../timecards/timecards","../projects/projects",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/projects/methods.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var moment = void 0;                                                                                                   // 1
module.importSync("moment", {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    moment = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Timecards = void 0;                                                                                                // 1
module.importSync("../timecards/timecards", {                                                                          // 1
  "default": function (v) {                                                                                            // 1
    Timecards = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Projects = void 0;                                                                                                 // 1
module.importSync("../projects/projects", {                                                                            // 1
  "default": function (v) {                                                                                            // 1
    Projects = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
Meteor.methods({                                                                                                       // 5
  'getProjectStats': function () {                                                                                     // 6
    if (!this.userId) {                                                                                                // 7
      throw new Meteor.Error('You have to be signed in to use this method.');                                          // 8
    }                                                                                                                  // 9
                                                                                                                       //
    var stats = [];                                                                                                    // 10
                                                                                                                       //
    for (var _iterator = Projects.find({                                                                               // 11
      userId: this.userId                                                                                              // 11
    }).fetch(), _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
      var _ref;                                                                                                        // 11
                                                                                                                       //
      if (_isArray) {                                                                                                  // 11
        if (_i >= _iterator.length) break;                                                                             // 11
        _ref = _iterator[_i++];                                                                                        // 11
      } else {                                                                                                         // 11
        _i = _iterator.next();                                                                                         // 11
        if (_i.done) break;                                                                                            // 11
        _ref = _i.value;                                                                                               // 11
      }                                                                                                                // 11
                                                                                                                       //
      var project = _ref;                                                                                              // 11
      var totalHours = 0;                                                                                              // 12
      var currentMonthHours = 0;                                                                                       // 13
      var previousMonthHours = 0;                                                                                      // 14
      var currentMonthStart = moment().startOf('month');                                                               // 15
      var currentMonthEnd = moment().endOf('month');                                                                   // 16
      var previousMonthStart = moment().startOf('month');                                                              // 17
      var previousMonthEnd = moment().endOf('month');                                                                  // 18
                                                                                                                       //
      for (var _iterator2 = Timecards.find({                                                                           // 20
        userId: this.userId,                                                                                           // 21
        projectId: project._id                                                                                         // 21
      }).fetch(), _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
        var _ref2;                                                                                                     // 21
                                                                                                                       //
        if (_isArray2) {                                                                                               // 21
          if (_i2 >= _iterator2.length) break;                                                                         // 21
          _ref2 = _iterator2[_i2++];                                                                                   // 21
        } else {                                                                                                       // 21
          _i2 = _iterator2.next();                                                                                     // 21
          if (_i2.done) break;                                                                                         // 21
          _ref2 = _i2.value;                                                                                           // 21
        }                                                                                                              // 21
                                                                                                                       //
        var timecard = _ref2;                                                                                          // 21
                                                                                                                       //
        if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                           // 22
          currentMonthHours += Number.parseFloat(timecard.hours);                                                      // 23
        }                                                                                                              // 24
                                                                                                                       //
        if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                         // 25
          previousMonthHours += Number.parseFloat(timecard.hours);                                                     // 26
        }                                                                                                              // 27
                                                                                                                       //
        totalHours += Number.parseFloat(timecard.hours);                                                               // 28
      }                                                                                                                // 29
                                                                                                                       //
      stats.push({                                                                                                     // 30
        _id: project._id,                                                                                              // 30
        name: project.name,                                                                                            // 31
        totalHours: totalHours,                                                                                        // 32
        currentMonthHours: currentMonthHours,                                                                          // 33
        previousMonthHours: previousMonthHours                                                                         // 34
      });                                                                                                              // 30
    }                                                                                                                  // 36
                                                                                                                       //
    return stats;                                                                                                      // 37
  },                                                                                                                   // 38
  'updateProject': function (_ref3) {                                                                                  // 39
    var projectId = _ref3.projectId,                                                                                   // 39
        projectArray = _ref3.projectArray;                                                                             // 39
                                                                                                                       //
    if (!this.userId) {                                                                                                // 40
      throw new Meteor.Error('You have to be signed in to use this method.');                                          // 41
    }                                                                                                                  // 42
                                                                                                                       //
    var updateJSON = {};                                                                                               // 43
                                                                                                                       //
    for (var _iterator3 = projectArray, _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
      var _ref4;                                                                                                       // 44
                                                                                                                       //
      if (_isArray3) {                                                                                                 // 44
        if (_i3 >= _iterator3.length) break;                                                                           // 44
        _ref4 = _iterator3[_i3++];                                                                                     // 44
      } else {                                                                                                         // 44
        _i3 = _iterator3.next();                                                                                       // 44
        if (_i3.done) break;                                                                                           // 44
        _ref4 = _i3.value;                                                                                             // 44
      }                                                                                                                // 44
                                                                                                                       //
      var projectAttribute = _ref4;                                                                                    // 44
      updateJSON[projectAttribute.name] = projectAttribute.value;                                                      // 45
    }                                                                                                                  // 46
                                                                                                                       //
    if (!updateJSON.public) {                                                                                          // 47
      updateJSON.public = false;                                                                                       // 48
    } else {                                                                                                           // 49
      updateJSON.public = true;                                                                                        // 50
    }                                                                                                                  // 51
                                                                                                                       //
    Projects.update({                                                                                                  // 52
      userId: this.userId,                                                                                             // 52
      _id: projectId                                                                                                   // 52
    }, {                                                                                                               // 52
      $set: updateJSON                                                                                                 // 52
    });                                                                                                                // 52
  },                                                                                                                   // 53
  'createProject': function (_ref5) {                                                                                  // 54
    var projectArray = _ref5.projectArray;                                                                             // 54
                                                                                                                       //
    if (!this.userId) {                                                                                                // 55
      throw new Meteor.Error('You have to be signed in to use this method.');                                          // 56
    }                                                                                                                  // 57
                                                                                                                       //
    var updateJSON = {};                                                                                               // 58
                                                                                                                       //
    for (var _iterator4 = projectArray, _isArray4 = Array.isArray(_iterator4), _i4 = 0, _iterator4 = _isArray4 ? _iterator4 : _iterator4[Symbol.iterator]();;) {
      var _ref6;                                                                                                       // 59
                                                                                                                       //
      if (_isArray4) {                                                                                                 // 59
        if (_i4 >= _iterator4.length) break;                                                                           // 59
        _ref6 = _iterator4[_i4++];                                                                                     // 59
      } else {                                                                                                         // 59
        _i4 = _iterator4.next();                                                                                       // 59
        if (_i4.done) break;                                                                                           // 59
        _ref6 = _i4.value;                                                                                             // 59
      }                                                                                                                // 59
                                                                                                                       //
      var projectAttribute = _ref6;                                                                                    // 59
      updateJSON[projectAttribute.name] = projectAttribute.value;                                                      // 60
    }                                                                                                                  // 61
                                                                                                                       //
    if (!updateJSON.public) {                                                                                          // 62
      updateJSON.public = false;                                                                                       // 63
    } else {                                                                                                           // 64
      updateJSON.public = true;                                                                                        // 65
    }                                                                                                                  // 66
                                                                                                                       //
    updateJSON.userId = this.userId;                                                                                   // 67
    Projects.insert(updateJSON);                                                                                       // 68
  },                                                                                                                   // 69
  'deleteProject': function (_ref7) {                                                                                  // 70
    var projectId = _ref7.projectId;                                                                                   // 70
                                                                                                                       //
    if (!this.userId) {                                                                                                // 71
      throw new Meteor.Error('You have to be signed in to use this method.');                                          // 72
    }                                                                                                                  // 73
                                                                                                                       //
    check(projectId, String);                                                                                          // 74
    Projects.remove({                                                                                                  // 75
      $or: [{                                                                                                          // 75
        userId: this.userId                                                                                            // 75
      }, {                                                                                                             // 75
        "public": true                                                                                                 // 75
      }],                                                                                                              // 75
      _id: projectId                                                                                                   // 75
    });                                                                                                                // 75
    return true;                                                                                                       // 76
  },                                                                                                                   // 77
  'getTopTasks': function (_ref8) {                                                                                    // 78
    var projectId = _ref8.projectId;                                                                                   // 78
                                                                                                                       //
    if (!this.userId) {                                                                                                // 79
      throw new Meteor.Error('You have to be signed in to use this method.');                                          // 80
    }                                                                                                                  // 81
                                                                                                                       //
    var rawCollection = Timecards.rawCollection();                                                                     // 82
    var aggregate = Meteor.wrapAsync(rawCollection.aggregate, rawCollection);                                          // 83
    return aggregate([{                                                                                                // 84
      $match: {                                                                                                        // 84
        projectId: projectId                                                                                           // 84
      }                                                                                                                // 84
    }, {                                                                                                               // 84
      $group: {                                                                                                        // 84
        _id: '$task',                                                                                                  // 84
        count: {                                                                                                       // 84
          $sum: 1                                                                                                      // 84
        }                                                                                                              // 84
      }                                                                                                                // 84
    }, {                                                                                                               // 84
      $sort: {                                                                                                         // 84
        count: -1                                                                                                      // 84
      }                                                                                                                // 84
    }, {                                                                                                               // 84
      $limit: 3                                                                                                        // 84
    }]);                                                                                                               // 84
  }                                                                                                                    // 85
});                                                                                                                    // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"projects.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/projects/projects.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
  ProjectStats: function () {                                                                                          // 1
    return ProjectStats;                                                                                               // 1
  },                                                                                                                   // 1
  "default": function () {                                                                                             // 1
    return Projects;                                                                                                   // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Mongo = void 0;                                                                                                    // 1
module.importSync("meteor/mongo", {                                                                                    // 1
  Mongo: function (v) {                                                                                                // 1
    Mongo = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Projects = new Mongo.Collection('projects');                                                                       // 3
var ProjectStats = new Mongo.Collection('projectStats');                                                               // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"setup.js":["./projects.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/projects/setup.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
  "default": function () {                                                                                             // 1
    return initNewUser;                                                                                                // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Projects = void 0;                                                                                                 // 1
module.importSync("./projects.js", {                                                                                   // 1
  "default": function (v) {                                                                                            // 1
    Projects = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
                                                                                                                       //
function initNewUser(userId, info) {                                                                                   // 3
  if (Meteor.settings.public.sandstorm) {                                                                              // 4
    if (!Projects.findOne({                                                                                            // 5
      "public": true                                                                                                   // 5
    })) {                                                                                                              // 5
      Projects.insert({                                                                                                // 6
        _id: 'sandstorm',                                                                                              // 7
        userId: userId,                                                                                                // 8
        name: info.profile.name + "'s Default Project",                                                                // 9
        desc: 'This project has been automatically created for you, feel free to change it!',                          // 10
        "public": true                                                                                                 // 11
      });                                                                                                              // 6
    }                                                                                                                  // 12
  } else {                                                                                                             // 13
    Projects.insert({                                                                                                  // 14
      userId: userId,                                                                                                  // 15
      name: info.profile.name + "'s Default Project",                                                                  // 16
      desc: 'This project has been automatically created for you, feel free to change it!'                             // 17
    });                                                                                                                // 14
  }                                                                                                                    // 18
}                                                                                                                      // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"tasks":{"server":{"publications.js":["meteor/check","../tasks.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/tasks/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var check = void 0;                                                                                                    // 1
module.importSync("meteor/check", {                                                                                    // 1
  check: function (v) {                                                                                                // 1
    check = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Tasks = void 0;                                                                                                    // 1
module.importSync("../tasks.js", {                                                                                     // 1
  "default": function (v) {                                                                                            // 1
    Tasks = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
// import Timecards from '../../timecards/timecards.js'                                                                // 3
// import Projects from '../../projects/projects.js'                                                                   // 4
Meteor.publish('mytasks', function () {                                                                                // 6
  function mytasks(filter) {                                                                                           // 6
    check(filter, String);                                                                                             // 7
                                                                                                                       //
    if (!this.userId) {                                                                                                // 8
      return this.ready();                                                                                             // 9
    }                                                                                                                  // 10
                                                                                                                       //
    if (filter) {                                                                                                      // 11
      check(filter, String); // check(filter, String)                                                                  // 12
                                                                                                                       //
      return Tasks.find({                                                                                              // 14
        userId: this.userId,                                                                                           // 14
        name: {                                                                                                        // 14
          $regex: ".*" + filter + ".*",                                                                                // 14
          $options: 'i'                                                                                                // 14
        }                                                                                                              // 14
      });                                                                                                              // 14
    }                                                                                                                  // 15
                                                                                                                       //
    return Tasks.find({                                                                                                // 16
      userId: this.userId                                                                                              // 16
    });                                                                                                                // 16
  }                                                                                                                    // 17
                                                                                                                       //
  return mytasks;                                                                                                      // 6
}()); // Meteor.publish('topTasks', function projectStats({ projectId }) {                                             // 6
//   check(projectId, String)                                                                                          // 19
//   if (!this.userId || !Projects.findOne({ _id: projectId,                                                           // 20
//     $or: [{ userId: this.userId }, { public: true }] })) {                                                          // 21
//     return this.ready()                                                                                             // 22
//   }                                                                                                                 // 23
//   const rawCollection = Timecards.rawCollection()                                                                   // 24
//   return rawCollection.aggregate([{ $match: { projectId } }, { $group: { _id: '$task', count: { $sum: 1 } } }])     // 25
// let initializing = true                                                                                             // 26
// const taskList = new Map()                                                                                          // 27
// // observeChanges only returns after the initial `added` callbacks                                                  // 28
// // have run. Until then, we don't want to send a lot of                                                             // 29
// // `self.changed()` messages - hence tracking the                                                                   // 30
// // `initializing` state.                                                                                            // 31
// const handle = Timecards.find({ projectId }).observeChanges({                                                       // 32
//   added: (_id) => {                                                                                                 // 33
//     if (!initializing) {                                                                                            // 34
//       const task = Timecards.findOne({ _id }).task                                                                  // 35
//       taskList.set(task, taskList.get(task) + 1)                                                                    // 36
//       this.changed('toptasks', projectId, { taskList })                                                             // 37
//     }                                                                                                               // 38
//   },                                                                                                                // 39
//   removed: (_id) => {                                                                                               // 40
//     if (!initializing) {                                                                                            // 41
//       const task = Timecards.findOne({ _id }).task                                                                  // 42
//       taskList.set(task, taskList.get(task) - 1)                                                                    // 43
//       this.changed('toptasks', projectId, { taskList })                                                             // 44
//     }                                                                                                               // 45
//   },                                                                                                                // 46
//   // changed: (timecardId) => {                                                                                     // 47
//   //   if (!initializing) {                                                                                         // 48
//   //     const timecard = Timecards.findOne({ _id: timecardId })                                                    // 49
//   //     if (moment(new Date(timecard.date)).isBetween(currentMonthStart, currentMonthEnd)) {                       // 50
//   //       currentMonthHours += Number.parseFloat(timecard.hours)                                                   // 51
//   //     }                                                                                                          // 52
//   //     if (moment(new Date(timecard.date)).isBetween(previousMonthStart, previousMonthEnd)) {                     // 53
//   //       previousMonthHours += Number.parseFloat(timecard.hours)                                                  // 54
//   //     }                                                                                                          // 55
//   //     if (moment(new Date(timecard.date))                                                                        // 56
//   //       .isBetween(beforePreviousMonthStart, beforePreviousMonthEnd)) {                                          // 57
//   //       beforePreviousMonthHours += Number.parseFloat(timecard.hours)                                            // 58
//   //     }                                                                                                          // 59
//   //     totalHours += Number.parseFloat(timecard.hours)                                                            // 60
//   //     this.changed('projectStats', projectId, { totalHours, currentMonthName, currentMonthHours, previousMonthHours, previousMonthName, beforePreviousMonthName, beforePreviousMonthHours })
//   //   }                                                                                                            // 62
//   // },                                                                                                             // 63
// })                                                                                                                  // 64
// // Instead, we'll send one `self.added()` message right after                                                       // 65
// // observeChanges has returned, and mark the subscription as                                                        // 66
// // ready.                                                                                                           // 67
// initializing = false                                                                                                // 68
// for (const timecard of Timecards.find({ projectId }).fetch()) {                                                     // 69
//   taskList.set(timecard.task, { task: timecard.task,                                                                // 70
//     count: taskList.get(timecard.task) ? (taskList.get(timecard.task).count + 1) : 1 })                             // 71
//   this.added('toptasks', timecard.task, { count: taskList.get(timecard.task) ? (taskList.get(timecard.task).count + 1) : 1 })
// }                                                                                                                   // 73
// // console.log(Array.from(taskList.values()))                                                                       // 74
//                                                                                                                     // 75
// // Stop observing the cursor when client unsubs.                                                                    // 76
// // Stopping a subscription automatically takes                                                                      // 77
// // care of sending the client any removed messages.                                                                 // 78
// this.onStop(() => {                                                                                                 // 79
//   handle.stop()                                                                                                     // 80
// })                                                                                                                  // 81
// return this.ready()                                                                                                 // 82
// })                                                                                                                  // 83
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/tasks/methods.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tasks.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/tasks/tasks.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
  TopTasks: function () {                                                                                              // 1
    return TopTasks;                                                                                                   // 1
  },                                                                                                                   // 1
  "default": function () {                                                                                             // 1
    return Tasks;                                                                                                      // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Mongo = void 0;                                                                                                    // 1
module.importSync("meteor/mongo", {                                                                                    // 1
  Mongo: function (v) {                                                                                                // 1
    Mongo = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Tasks = new Mongo.Collection('tasks');                                                                             // 3
var TopTasks = new Mongo.Collection('toptasks');                                                                       // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"timecards":{"server":{"publications.js":["moment","../timecards.js","../../projects/projects.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/timecards/server/publications.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var moment = void 0;                                                                                                   // 1
module.importSync("moment", {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    moment = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Timecards = void 0;                                                                                                // 1
module.importSync("../timecards.js", {                                                                                 // 1
  "default": function (v) {                                                                                            // 1
    Timecards = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Projects = void 0;                                                                                                 // 1
module.importSync("../../projects/projects.js", {                                                                      // 1
  "default": function (v) {                                                                                            // 1
    Projects = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
Meteor.publish('projectTimecards', function () {                                                                       // 5
  function projectTimecards(_ref) {                                                                                    // 5
    var projectId = _ref.projectId,                                                                                    // 5
        period = _ref.period,                                                                                          // 5
        userId = _ref.userId;                                                                                          // 5
    // console.log(projectId)                                                                                          // 6
    var projectList = [];                                                                                              // 7
                                                                                                                       //
    if (projectId === 'all') {                                                                                         // 8
      projectList = Projects.find({                                                                                    // 9
        $or: [{                                                                                                        // 9
          userId: this.userId                                                                                          // 9
        }, {                                                                                                           // 9
          "public": true                                                                                               // 9
        }]                                                                                                             // 9
      }, {                                                                                                             // 9
        $fields: {                                                                                                     // 10
          _id: 1                                                                                                       // 10
        }                                                                                                              // 10
      }).fetch().map(function (value) {                                                                                // 10
        return value._id;                                                                                              // 10
      });                                                                                                              // 10
    } else {                                                                                                           // 11
      projectList = [Projects.findOne({                                                                                // 12
        _id: projectId                                                                                                 // 12
      })._id];                                                                                                         // 12
    } // const project = Projects.findOne({ _id: { $in: projectList } })                                               // 13
    // if (!this.userId || (!Timecards.findOne({ projectId, userId: this.userId })) {                                  // 15
    //   return this.ready()                                                                                           // 16
    // }                                                                                                               // 17
                                                                                                                       //
                                                                                                                       //
    if (period && period !== 'all') {                                                                                  // 18
      var startDate = void 0;                                                                                          // 19
      var endDate = void 0;                                                                                            // 20
                                                                                                                       //
      switch (period) {                                                                                                // 21
        default:                                                                                                       // 22
          startDate = moment().startOf('month').toDate();                                                              // 23
          endDate = moment().endOf('month').toDate();                                                                  // 24
          break;                                                                                                       // 25
                                                                                                                       //
        case 'currentWeek':                                                                                            // 26
          startDate = moment().startOf('week').toDate();                                                               // 27
          endDate = moment().endOf('week').toDate();                                                                   // 28
          break;                                                                                                       // 29
                                                                                                                       //
        case 'lastMonth':                                                                                              // 30
          startDate = moment().subtract(1, 'month').startOf('month').toDate();                                         // 31
          endDate = moment().subtract(1, 'month').endOf('month').toDate();                                             // 32
          break;                                                                                                       // 33
                                                                                                                       //
        case 'lastWeek':                                                                                               // 34
          startDate = moment().subtract(1, 'week').startOf('week').toDate();                                           // 35
          endDate = moment().subtract(1, 'week').endOf('week').toDate();                                               // 36
          break;                                                                                                       // 37
      }                                                                                                                // 21
                                                                                                                       //
      if (userId === 'all') {                                                                                          // 39
        return Timecards.find({                                                                                        // 40
          projectId: {                                                                                                 // 40
            $in: projectList                                                                                           // 40
          },                                                                                                           // 40
          date: {                                                                                                      // 41
            $gte: startDate,                                                                                           // 41
            $lte: endDate                                                                                              // 41
          }                                                                                                            // 41
        });                                                                                                            // 40
      }                                                                                                                // 42
                                                                                                                       //
      return Timecards.find({                                                                                          // 43
        projectId: {                                                                                                   // 43
          $in: projectList                                                                                             // 43
        },                                                                                                             // 43
        userId: userId,                                                                                                // 44
        date: {                                                                                                        // 45
          $gte: startDate,                                                                                             // 45
          $lte: endDate                                                                                                // 45
        }                                                                                                              // 45
      });                                                                                                              // 43
    }                                                                                                                  // 46
                                                                                                                       //
    if (userId === 'all') {                                                                                            // 47
      return Timecards.find({                                                                                          // 48
        projectId: {                                                                                                   // 48
          $in: projectList                                                                                             // 48
        }                                                                                                              // 48
      });                                                                                                              // 48
    }                                                                                                                  // 49
                                                                                                                       //
    return Timecards.find({                                                                                            // 50
      projectId: {                                                                                                     // 50
        $in: projectList                                                                                               // 50
      },                                                                                                               // 50
      userId: userId                                                                                                   // 50
    });                                                                                                                // 50
  }                                                                                                                    // 51
                                                                                                                       //
  return projectTimecards;                                                                                             // 5
}());                                                                                                                  // 5
Meteor.publish('periodTimecards', function () {                                                                        // 53
  function periodTimecards(_ref2) {                                                                                    // 53
    var startDate = _ref2.startDate,                                                                                   // 53
        endDate = _ref2.endDate,                                                                                       // 53
        userId = _ref2.userId;                                                                                         // 53
    var projectList = Projects.find({                                                                                  // 54
      $or: [{                                                                                                          // 54
        userId: this.userId                                                                                            // 54
      }, {                                                                                                             // 54
        "public": true                                                                                                 // 54
      }]                                                                                                               // 54
    }, {                                                                                                               // 54
      $fields: {                                                                                                       // 55
        _id: 1                                                                                                         // 55
      }                                                                                                                // 55
    }).fetch().map(function (value) {                                                                                  // 55
      return value._id;                                                                                                // 55
    });                                                                                                                // 55
                                                                                                                       //
    if (userId === 'all') {                                                                                            // 57
      return Timecards.find({                                                                                          // 58
        projectId: {                                                                                                   // 58
          $in: projectList                                                                                             // 58
        },                                                                                                             // 58
        date: {                                                                                                        // 59
          $gte: startDate,                                                                                             // 59
          $lte: endDate                                                                                                // 59
        }                                                                                                              // 59
      });                                                                                                              // 58
    }                                                                                                                  // 60
                                                                                                                       //
    return Timecards.find({                                                                                            // 61
      projectId: {                                                                                                     // 61
        $in: projectList                                                                                               // 61
      },                                                                                                               // 61
      userId: userId,                                                                                                  // 62
      date: {                                                                                                          // 63
        $gte: startDate,                                                                                               // 63
        $lte: endDate                                                                                                  // 63
      }                                                                                                                // 63
    });                                                                                                                // 61
  }                                                                                                                    // 64
                                                                                                                       //
  return periodTimecards;                                                                                              // 53
}());                                                                                                                  // 53
Meteor.publish('singleTimecard', function () {                                                                         // 66
  function singleTimecard(_id) {                                                                                       // 66
    check(_id, String);                                                                                                // 67
    var timecard = Timecards.findOne({                                                                                 // 68
      _id: _id                                                                                                         // 68
    });                                                                                                                // 68
    var project = Projects.findOne({                                                                                   // 69
      _id: timecard.projectId                                                                                          // 69
    });                                                                                                                // 69
                                                                                                                       //
    if (!this.userId || !Timecards.findOne({                                                                           // 70
      userId: this.userId                                                                                              // 70
    }) && !project.public) {                                                                                           // 70
      return this.ready();                                                                                             // 71
    }                                                                                                                  // 72
                                                                                                                       //
    return Timecards.find({                                                                                            // 73
      _id: _id                                                                                                         // 73
    });                                                                                                                // 73
  }                                                                                                                    // 74
                                                                                                                       //
  return singleTimecard;                                                                                               // 66
}());                                                                                                                  // 66
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["moment","fast-csv","./timecards.js","../tasks/tasks.js","../projects/projects.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/timecards/methods.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var moment = void 0;                                                                                                   // 1
module.importSync("moment", {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    moment = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var csv = void 0;                                                                                                      // 1
module.importSync("fast-csv", {                                                                                        // 1
  "default": function (v) {                                                                                            // 1
    csv = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Timecards = void 0;                                                                                                // 1
module.importSync("./timecards.js", {                                                                                  // 1
  "default": function (v) {                                                                                            // 1
    Timecards = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Tasks = void 0;                                                                                                    // 1
module.importSync("../tasks/tasks.js", {                                                                               // 1
  "default": function (v) {                                                                                            // 1
    Tasks = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var Projects = void 0;                                                                                                 // 1
module.importSync("../projects/projects.js", {                                                                         // 1
  "default": function (v) {                                                                                            // 1
    Projects = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
Meteor.methods({                                                                                                       // 7
  'insertTimeCard': function (_ref) {                                                                                  // 8
    var projectId = _ref.projectId,                                                                                    // 8
        task = _ref.task,                                                                                              // 8
        date = _ref.date,                                                                                              // 8
        hours = _ref.hours;                                                                                            // 8
                                                                                                                       //
    if (!this.userId) {                                                                                                // 9
      throw new Meteor.Error('You have to be signed in to use this method.');                                          // 10
    }                                                                                                                  // 11
                                                                                                                       //
    if (!Tasks.findOne({                                                                                               // 12
      userId: this.userId,                                                                                             // 12
      name: task                                                                                                       // 12
    })) {                                                                                                              // 12
      Tasks.insert({                                                                                                   // 13
        userId: this.userId,                                                                                           // 13
        name: task                                                                                                     // 13
      });                                                                                                              // 13
    }                                                                                                                  // 14
                                                                                                                       //
    Timecards.insert({                                                                                                 // 15
      userId: this.userId,                                                                                             // 15
      projectId: projectId,                                                                                            // 15
      date: date,                                                                                                      // 15
      hours: hours,                                                                                                    // 15
      task: task                                                                                                       // 15
    });                                                                                                                // 15
  },                                                                                                                   // 16
  'updateTimeCard': function (_ref2) {                                                                                 // 17
    var _id = _ref2._id,                                                                                               // 17
        task = _ref2.task,                                                                                             // 17
        date = _ref2.date,                                                                                             // 17
        hours = _ref2.hours;                                                                                           // 17
                                                                                                                       //
    if (!this.userId) {                                                                                                // 18
      throw new Meteor.Error('You have to be signed in to use this method.');                                          // 19
    }                                                                                                                  // 20
                                                                                                                       //
    if (!Tasks.findOne({                                                                                               // 21
      userId: this.userId,                                                                                             // 21
      name: task                                                                                                       // 21
    })) {                                                                                                              // 21
      Tasks.insert({                                                                                                   // 22
        userId: this.userId,                                                                                           // 22
        name: task                                                                                                     // 22
      });                                                                                                              // 22
    }                                                                                                                  // 23
                                                                                                                       //
    Timecards.update({                                                                                                 // 24
      _id: _id                                                                                                         // 24
    }, {                                                                                                               // 24
      $set: {                                                                                                          // 24
        date: date,                                                                                                    // 24
        hours: hours,                                                                                                  // 24
        task: task                                                                                                     // 24
      }                                                                                                                // 24
    });                                                                                                                // 24
  },                                                                                                                   // 25
  'export': function (_ref3) {                                                                                         // 26
    var projectId = _ref3.projectId,                                                                                   // 26
        timePeriod = _ref3.timePeriod,                                                                                 // 26
        userId = _ref3.userId;                                                                                         // 26
                                                                                                                       //
    if (!this.userId) {                                                                                                // 27
      throw new Meteor.Error('You have to be signed in to use this method.');                                          // 28
    }                                                                                                                  // 29
                                                                                                                       //
    var startDate = void 0;                                                                                            // 30
    var endDate = void 0;                                                                                              // 31
                                                                                                                       //
    switch (timePeriod) {                                                                                              // 32
      default:                                                                                                         // 33
        startDate = moment().startOf('month').toDate();                                                                // 34
        endDate = moment().endOf('month').toDate();                                                                    // 35
        break;                                                                                                         // 36
                                                                                                                       //
      case 'currentWeek':                                                                                              // 37
        startDate = moment().startOf('week').toDate();                                                                 // 38
        endDate = moment().endOf('week').toDate();                                                                     // 39
        break;                                                                                                         // 40
                                                                                                                       //
      case 'lastMonth':                                                                                                // 41
        startDate = moment().subtract(1, 'month').startOf('month').toDate();                                           // 42
        endDate = moment().subtract(1, 'month').endOf('month').toDate();                                               // 43
        break;                                                                                                         // 44
                                                                                                                       //
      case 'lastWeek':                                                                                                 // 45
        startDate = moment().subtract(1, 'week').startOf('week').toDate();                                             // 46
        endDate = moment().subtract(1, 'week').endOf('week').toDate();                                                 // 47
        break;                                                                                                         // 48
    }                                                                                                                  // 32
                                                                                                                       //
    var timecardArray = [];                                                                                            // 50
    var projectList = [];                                                                                              // 51
                                                                                                                       //
    if (projectId === 'all') {                                                                                         // 52
      projectList = Projects.find({                                                                                    // 53
        $or: [{                                                                                                        // 53
          userId: this.userId                                                                                          // 53
        }, {                                                                                                           // 53
          "public": true                                                                                               // 53
        }]                                                                                                             // 53
      }, {                                                                                                             // 53
        _id: 1                                                                                                         // 54
      }).fetch().map(function (value) {                                                                                // 54
        return value._id;                                                                                              // 54
      });                                                                                                              // 54
    } else {                                                                                                           // 55
      projectList = [projectId];                                                                                       // 56
    }                                                                                                                  // 57
                                                                                                                       //
    if (userId !== 'all') {                                                                                            // 58
      timecardArray = Timecards.find({                                                                                 // 59
        userId: userId,                                                                                                // 59
        projectId: {                                                                                                   // 60
          $in: projectList                                                                                             // 60
        },                                                                                                             // 60
        date: {                                                                                                        // 61
          $gte: startDate,                                                                                             // 61
          $lte: endDate                                                                                                // 61
        }                                                                                                              // 61
      }).fetch();                                                                                                      // 59
    } else {                                                                                                           // 62
      timecardArray = Timecards.find({                                                                                 // 63
        projectId: {                                                                                                   // 63
          $in: projectList                                                                                             // 63
        },                                                                                                             // 63
        date: {                                                                                                        // 64
          $gte: startDate,                                                                                             // 64
          $lte: endDate                                                                                                // 64
        }                                                                                                              // 64
      }).fetch();                                                                                                      // 63
    }                                                                                                                  // 65
                                                                                                                       //
    for (var _iterator = timecardArray, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
      var _ref4;                                                                                                       // 66
                                                                                                                       //
      if (_isArray) {                                                                                                  // 66
        if (_i >= _iterator.length) break;                                                                             // 66
        _ref4 = _iterator[_i++];                                                                                       // 66
      } else {                                                                                                         // 66
        _i = _iterator.next();                                                                                         // 66
        if (_i.done) break;                                                                                            // 66
        _ref4 = _i.value;                                                                                              // 66
      }                                                                                                                // 66
                                                                                                                       //
      var timecard = _ref4;                                                                                            // 66
      timecard.date = moment(timecard.date).format('DD.MM.YYYY');                                                      // 67
      timecard.Resource = Meteor.users.findOne({                                                                       // 68
        _id: timecard.userId                                                                                           // 68
      }).profile.name;                                                                                                 // 68
      timecard.Project = Projects.findOne({                                                                            // 69
        _id: timecard.projectId                                                                                        // 69
      }).name;                                                                                                         // 69
      delete timecard.userId;                                                                                          // 70
      delete timecard.projectId;                                                                                       // 71
      delete timecard._id;                                                                                             // 72
    }                                                                                                                  // 73
                                                                                                                       //
    return new Promise(function (resolve, reject) {                                                                    // 74
      csv.writeToString(timecardArray, {                                                                               // 75
        headers: true,                                                                                                 // 75
        delimiter: '\t'                                                                                                // 75
      }, function (error, data) {                                                                                      // 75
        if (error) {                                                                                                   // 76
          reject(error);                                                                                               // 77
        } else {                                                                                                       // 78
          resolve(data);                                                                                               // 79
        }                                                                                                              // 80
      });                                                                                                              // 81
    }); // return new Buffer(json2xls(Timecards.find({ userId: this.userId,                                            // 82
    //   projectId,                                                                                                    // 84
    //   date: { $gte: startDate, $lte: endDate } }).fetch())).toString('base64')                                      // 85
  },                                                                                                                   // 86
  'deleteTimeCard': function (_ref5) {                                                                                 // 87
    var timecardId = _ref5.timecardId;                                                                                 // 87
                                                                                                                       //
    if (!this.userId) {                                                                                                // 88
      throw new Meteor.Error('You have to be signed in to use this method.');                                          // 89
    }                                                                                                                  // 90
                                                                                                                       //
    Timecards.remove({                                                                                                 // 91
      userId: this.userId,                                                                                             // 91
      _id: timecardId                                                                                                  // 91
    });                                                                                                                // 91
    return true;                                                                                                       // 92
  }                                                                                                                    // 93
});                                                                                                                    // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"tabular.js":["meteor/aldeed:tabular","moment","meteor/kadira:flow-router","meteor/templating","./timecards.js","../projects/projects.js","../users/users.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/timecards/tabular.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Tabular = void 0;                                                                                                  // 1
module.importSync("meteor/aldeed:tabular", {                                                                           // 1
  "default": function (v) {                                                                                            // 1
    Tabular = v;                                                                                                       // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var moment = void 0;                                                                                                   // 1
module.importSync("moment", {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    moment = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var FlowRouter = void 0;                                                                                               // 1
module.importSync("meteor/kadira:flow-router", {                                                                       // 1
  FlowRouter: function (v) {                                                                                           // 1
    FlowRouter = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Template = void 0;                                                                                                 // 1
module.importSync("meteor/templating", {                                                                               // 1
  Template: function (v) {                                                                                             // 1
    Template = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var Timecards = void 0;                                                                                                // 1
module.importSync("./timecards.js", {                                                                                  // 1
  "default": function (v) {                                                                                            // 1
    Timecards = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Projects = void 0;                                                                                                 // 1
module.importSync("../projects/projects.js", {                                                                         // 1
  "default": function (v) {                                                                                            // 1
    Projects = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
var projectUsers = void 0;                                                                                             // 1
module.importSync("../users/users.js", {                                                                               // 1
  "default": function (v) {                                                                                            // 1
    projectUsers = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 6);                                                                                                                 // 1
// import '../../ui/components/tablecell.js'                                                                           // 8
new Tabular.Table({                                                                                                    // 10
  name: 'Timecards',                                                                                                   // 11
  collection: Timecards,                                                                                               // 12
  columns: [{                                                                                                          // 13
    data: 'projectId',                                                                                                 // 14
    title: 'Project',                                                                                                  // 14
    render: function (_id) {                                                                                           // 14
      return Projects.findOne({                                                                                        // 14
        _id: _id                                                                                                       // 14
      }).name;                                                                                                         // 14
    }                                                                                                                  // 14
  }, {                                                                                                                 // 14
    data: 'date',                                                                                                      // 15
    title: 'Date',                                                                                                     // 15
    render: function (val) {                                                                                           // 15
      return moment(val).format('ddd DD.MM.YYYY');                                                                     // 15
    }                                                                                                                  // 15
  }, {                                                                                                                 // 15
    data: 'task',                                                                                                      // 16
    title: 'Task'                                                                                                      // 16
  }, {                                                                                                                 // 16
    data: 'userId',                                                                                                    // 17
    title: 'Resource',                                                                                                 // 18
    render: function (_id, type, doc) {                                                                                // 19
      Meteor.subscribe('projectUsers', {                                                                               // 20
        projectId: doc.projectId                                                                                       // 20
      });                                                                                                              // 20
      return projectUsers.findOne({                                                                                    // 21
        _id: doc.projectId                                                                                             // 21
      }) ? projectUsers.findOne({                                                                                      // 21
        _id: doc.projectId                                                                                             // 22
      }).users.find(function (elem) {                                                                                  // 22
        return elem._id === _id;                                                                                       // 23
      }).profile.name : false;                                                                                         // 23
    }                                                                                                                  // 24
  }, {                                                                                                                 // 17
    data: 'hours',                                                                                                     // 26
    titleFn: function () {                                                                                             // 27
      if (Meteor.user()) {                                                                                             // 28
        return Meteor.user().profile.timeunit === 'd' ? 'Days' : 'Hours';                                              // 29
      }                                                                                                                // 30
                                                                                                                       //
      return 'Hours';                                                                                                  // 31
    },                                                                                                                 // 32
    render: function (_id, type, doc) {                                                                                // 33
      if (Meteor.user()) {                                                                                             // 34
        if (Meteor.user().profile.timeunit === 'd') {                                                                  // 35
          var convertedTime = Number(doc.hours / (Meteor.user().profile.hoursToDays ? Meteor.user().profile.hoursToDays : 8)).toFixed(2);
          return convertedTime !== Number(0).toFixed(2) ? convertedTime : undefined;                                   // 38
        }                                                                                                              // 39
      }                                                                                                                // 40
                                                                                                                       //
      return doc.hours;                                                                                                // 41
    }                                                                                                                  // 42
  }, {                                                                                                                 // 26
    title: 'Edit / delete',                                                                                            // 45
    data: 'this',                                                                                                      // 46
    tmpl: Meteor.isClient && Template.tablecell,                                                                       // 47
    className: 'text-right'                                                                                            // 48
  }],                                                                                                                  // 44
  selector: function (userId) {                                                                                        // 51
    var projectList = Projects.find({                                                                                  // 52
      $or: [{                                                                                                          // 52
        userId: userId                                                                                                 // 52
      }, {                                                                                                             // 52
        "public": true                                                                                                 // 52
      }]                                                                                                               // 52
    }, {                                                                                                               // 52
      $fields: {                                                                                                       // 53
        _id: 1                                                                                                         // 53
      }                                                                                                                // 53
    }).fetch().map(function (value) {                                                                                  // 53
      return value._id;                                                                                                // 53
    });                                                                                                                // 53
    return {                                                                                                           // 54
      projectId: {                                                                                                     // 54
        $in: projectList                                                                                               // 54
      }                                                                                                                // 54
    };                                                                                                                 // 54
  },                                                                                                                   // 55
  columnDefs: [{                                                                                                       // 56
    targets: 5,                                                                                                        // 57
    orderable: false                                                                                                   // 58
  }],                                                                                                                  // 56
  responsive: true,                                                                                                    // 60
  autoWidth: false,                                                                                                    // 61
  buttonContainer: '.row:eq(0)',                                                                                       // 62
  // buttons: ['excelHtml5', 'csvHtml5'],                                                                              // 63
  buttons: [{                                                                                                          // 64
    text: '<i class="fa fa-plus"></i> Time',                                                                           // 66
    action: function () {                                                                                              // 67
      FlowRouter.go('tracktime', {                                                                                     // 68
        projectId: $('#targetProject').val()                                                                           // 68
      });                                                                                                              // 68
    }                                                                                                                  // 69
  }, {                                                                                                                 // 65
    extend: 'excelHtml5',                                                                                              // 72
    className: 'btn-primary',                                                                                          // 73
    text: '<i class="fa fa-download"></i> Excel',                                                                      // 74
    title: "titra_export_" + moment().format('YYYYMMDD-HHmm'),                                                         // 75
    exportOptions: {                                                                                                   // 76
      columns: [0, 1, 2, 3, 4]                                                                                         // 77
    }                                                                                                                  // 76
  }, {                                                                                                                 // 71
    extend: 'csvHtml5',                                                                                                // 81
    className: 'btn-primary',                                                                                          // 82
    text: '<i class="fa fa-download"></i> CSV',                                                                        // 83
    title: "titra_export_" + moment().format('YYYYMMDD-HHmm'),                                                         // 84
    exportOptions: {                                                                                                   // 85
      columns: [0, 1, 2, 3, 4]                                                                                         // 86
    }                                                                                                                  // 85
  }]                                                                                                                   // 80
});                                                                                                                    // 10
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"timecards.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/timecards/timecards.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
  "default": function () {                                                                                             // 1
    return Timecards;                                                                                                  // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Mongo = void 0;                                                                                                    // 1
module.importSync("meteor/mongo", {                                                                                    // 1
  Mongo: function (v) {                                                                                                // 1
    Mongo = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Timecards = new Mongo.Collection('timecards');                                                                     // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"users":{"server":{"publications.js":["babel-runtime/helpers/toConsumableArray","../../timecards/timecards.js","../../projects/projects.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/users/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");                                          //
                                                                                                                       //
var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);                                                 //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
var Timecards = void 0;                                                                                                // 1
module.importSync("../../timecards/timecards.js", {                                                                    // 1
  "default": function (v) {                                                                                            // 1
    Timecards = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Projects = void 0;                                                                                                 // 1
module.importSync("../../projects/projects.js", {                                                                      // 1
  "default": function (v) {                                                                                            // 1
    Projects = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
Meteor.publish('projectUsers', function () {                                                                           // 4
  function projectUsers(_ref) {                                                                                        // 4
    var _this = this;                                                                                                  // 4
                                                                                                                       //
    var projectId = _ref.projectId;                                                                                    // 4
    check(projectId, String);                                                                                          // 5
    var userIds = [];                                                                                                  // 6
    var handle = void 0;                                                                                               // 7
    var initializing = true;                                                                                           // 8
    var uniqueUsers = void 0;                                                                                          // 9
                                                                                                                       //
    if (projectId === 'all') {                                                                                         // 10
      var projectList = Projects.find({                                                                                // 11
        $or: [{                                                                                                        // 11
          userId: this.userId                                                                                          // 11
        }, {                                                                                                           // 11
          "public": true                                                                                               // 11
        }]                                                                                                             // 11
      }, {                                                                                                             // 11
        _id: 1                                                                                                         // 12
      }).fetch().map(function (value) {                                                                                // 12
        return value._id;                                                                                              // 12
      });                                                                                                              // 12
                                                                                                                       //
      if (Timecards.find({                                                                                             // 13
        projectId: {                                                                                                   // 13
          $in: projectList                                                                                             // 13
        }                                                                                                              // 13
      }).count() <= 0) {                                                                                               // 13
        return this.ready();                                                                                           // 14
      }                                                                                                                // 15
                                                                                                                       //
      Timecards.find({                                                                                                 // 16
        projectId: {                                                                                                   // 16
          $in: projectList                                                                                             // 16
        }                                                                                                              // 16
      }).forEach(function (timecard) {                                                                                 // 16
        userIds.push(timecard.userId);                                                                                 // 17
      });                                                                                                              // 18
      handle = Timecards.find({                                                                                        // 19
        projectId: {                                                                                                   // 19
          $in: projectList                                                                                             // 19
        }                                                                                                              // 19
      }).observeChanges({                                                                                              // 19
        added: function (_id) {                                                                                        // 20
          if (!initializing) {                                                                                         // 21
            userIds.push(Timecards.findOne(_id).userId);                                                               // 22
            uniqueUsers = [].concat((0, _toConsumableArray3.default)(new Set(userIds)));                               // 23
                                                                                                                       //
            _this.added('projectUsers', projectId, {                                                                   // 24
              users: Meteor.users.find({                                                                               // 24
                _id: {                                                                                                 // 24
                  $in: uniqueUsers                                                                                     // 24
                }                                                                                                      // 24
              }, {                                                                                                     // 24
                profile: 1                                                                                             // 24
              }).fetch()                                                                                               // 24
            });                                                                                                        // 24
          }                                                                                                            // 25
        },                                                                                                             // 26
        removed: function (_id) {                                                                                      // 27
          if (!initializing) {                                                                                         // 28
            userIds.splice(userIds.indexOf(Timecards.findOne(_id).userId), 1);                                         // 29
            uniqueUsers = [].concat((0, _toConsumableArray3.default)(new Set(userIds)));                               // 30
                                                                                                                       //
            _this.changed('projectUsers', projectId, {                                                                 // 31
              users: Meteor.users.find({                                                                               // 31
                _id: {                                                                                                 // 31
                  $in: uniqueUsers                                                                                     // 31
                }                                                                                                      // 31
              }, {                                                                                                     // 31
                profile: 1                                                                                             // 31
              }).fetch()                                                                                               // 31
            });                                                                                                        // 31
          }                                                                                                            // 32
        }                                                                                                              // 33
      });                                                                                                              // 19
    } else {                                                                                                           // 36
      Timecards.find({                                                                                                 // 37
        projectId: projectId                                                                                           // 37
      }).forEach(function (timecard) {                                                                                 // 37
        userIds.push(timecard.userId);                                                                                 // 38
      });                                                                                                              // 39
      handle = Timecards.find({                                                                                        // 40
        projectId: projectId                                                                                           // 40
      }).observeChanges({                                                                                              // 40
        added: function (_id) {                                                                                        // 41
          if (!initializing) {                                                                                         // 42
            userIds.push(Timecards.findOne(_id).userId);                                                               // 43
            uniqueUsers = [].concat((0, _toConsumableArray3.default)(new Set(userIds)));                               // 44
                                                                                                                       //
            _this.added('projectUsers', projectId, {                                                                   // 45
              users: Meteor.users.find({                                                                               // 45
                _id: {                                                                                                 // 45
                  $in: uniqueUsers                                                                                     // 45
                }                                                                                                      // 45
              }, {                                                                                                     // 45
                profile: 1                                                                                             // 45
              }).fetch()                                                                                               // 45
            });                                                                                                        // 45
          }                                                                                                            // 46
        },                                                                                                             // 47
        removed: function () {                                                                                         // 48
          if (!initializing) {                                                                                         // 49
            userIds = [];                                                                                              // 50
            Timecards.find({                                                                                           // 51
              projectId: projectId                                                                                     // 51
            }).forEach(function (timecard) {                                                                           // 51
              userIds.push(timecard.userId);                                                                           // 52
            });                                                                                                        // 53
            uniqueUsers = [].concat((0, _toConsumableArray3.default)(new Set(userIds)));                               // 54
                                                                                                                       //
            _this.changed('projectUsers', projectId, {                                                                 // 55
              users: Meteor.users.find({                                                                               // 55
                _id: {                                                                                                 // 55
                  $in: uniqueUsers                                                                                     // 55
                }                                                                                                      // 55
              }, {                                                                                                     // 55
                profile: 1                                                                                             // 55
              }).fetch()                                                                                               // 55
            });                                                                                                        // 55
          }                                                                                                            // 56
        }                                                                                                              // 57
      });                                                                                                              // 40
    }                                                                                                                  // 59
                                                                                                                       //
    uniqueUsers = [].concat((0, _toConsumableArray3.default)(new Set(userIds))); // observeChanges only returns after the initial `added` callbacks
    // have run. Until then, we don't want to send a lot of                                                            // 62
    // `self.changed()` messages - hence tracking the                                                                  // 63
    // `initializing` state.                                                                                           // 64
    // Instead, we'll send one `self.added()` message right after                                                      // 65
    // observeChanges has returned, and mark the subscription as                                                       // 66
    // ready.                                                                                                          // 67
                                                                                                                       //
    initializing = false;                                                                                              // 68
    this.added('projectUsers', projectId, {                                                                            // 69
      users: Meteor.users.find({                                                                                       // 69
        _id: {                                                                                                         // 69
          $in: uniqueUsers                                                                                             // 69
        }                                                                                                              // 69
      }, {                                                                                                             // 69
        profile: 1                                                                                                     // 69
      }).fetch()                                                                                                       // 69
    });                                                                                                                // 69
    this.ready(); // Stop observing the cursor when client unsubs.                                                     // 70
    // Stopping a subscription automatically takes                                                                     // 72
    // care of sending the client any removed messages.                                                                // 73
                                                                                                                       //
    this.onStop(function () {                                                                                          // 74
      handle.stop();                                                                                                   // 75
    }); // return Meteor.users.find({ _id: { $in: uniqueUsers } })                                                     // 76
  }                                                                                                                    // 78
                                                                                                                       //
  return projectUsers;                                                                                                 // 4
}());                                                                                                                  // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/users/methods.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// import Timecards from '../timecards/timecards.js'                                                                   // 1
// import Projects from '../projects/projects.js'                                                                      // 2
Meteor.methods({                                                                                                       // 4
  // getResourcesInProject({ projectId }) {                                                                            // 5
  //   // const project = Projects.findOne({ _id: projectId })                                                         // 6
  //   const userIds = []                                                                                              // 7
  //   for (const timecard of Timecards.find({ projectId }).fetch()) {                                                 // 8
  //     userIds.push(timecard.userId)                                                                                 // 9
  //   }                                                                                                               // 10
  //   const uniqueUsers = [...new Set(userIds)]                                                                       // 11
  //   return Meteor.users.find({ _id: { $in: uniqueUsers } }, { 'profile.name': 1 }).fetch()                          // 12
  // },                                                                                                                // 13
  updateSettings: function (_ref) {                                                                                    // 14
    var name = _ref.name,                                                                                              // 14
        unit = _ref.unit,                                                                                              // 14
        timeunit = _ref.timeunit,                                                                                      // 14
        timetrackview = _ref.timetrackview;                                                                            // 14
    check(name, String);                                                                                               // 15
    check(unit, String);                                                                                               // 16
    check(timeunit, String);                                                                                           // 17
    check(timetrackview, String);                                                                                      // 18
    Meteor.users.update({                                                                                              // 19
      _id: this.userId                                                                                                 // 19
    }, {                                                                                                               // 19
      $set: {                                                                                                          // 19
        'profile.name': name,                                                                                          // 19
        'profile.unit': unit,                                                                                          // 19
        'profile.timeunit': timeunit,                                                                                  // 19
        'profile.timetrackview': timetrackview                                                                         // 19
      }                                                                                                                // 19
    });                                                                                                                // 19
  }                                                                                                                    // 20
});                                                                                                                    // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/users/users.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Mongo = void 0;                                                                                                    // 1
module.importSync("meteor/mongo", {                                                                                    // 1
  Mongo: function (v) {                                                                                                // 1
    Mongo = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var projectUsers = new Mongo.Collection('projectUsers');                                                               // 3
module.export("default", exports.default = projectUsers);                                                              // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"index.js":["../../api/projects/projects.js","../../api/projects/methods.js","../../api/projects/server/publications.js","../../api/timecards/timecards.js","../../api/timecards/server/publications.js","../../api/timecards/methods.js","../../api/tasks/tasks.js","../../api/tasks/server/publications.js","../../api/tasks/methods.js","../../api/users/server/publications.js","../../api/users/methods.js","../../api/timecards/tabular.js","./useraccounts-configuration.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.importSync("../../api/projects/projects.js");                                                                   // 1
module.importSync("../../api/projects/methods.js");                                                                    // 1
module.importSync("../../api/projects/server/publications.js");                                                        // 1
module.importSync("../../api/timecards/timecards.js");                                                                 // 1
module.importSync("../../api/timecards/server/publications.js");                                                       // 1
module.importSync("../../api/timecards/methods.js");                                                                   // 1
module.importSync("../../api/tasks/tasks.js");                                                                         // 1
module.importSync("../../api/tasks/server/publications.js");                                                           // 1
module.importSync("../../api/tasks/methods.js");                                                                       // 1
module.importSync("../../api/users/server/publications.js");                                                           // 1
module.importSync("../../api/users/methods.js");                                                                       // 1
module.importSync("../../api/timecards/tabular.js");                                                                   // 1
module.importSync("./useraccounts-configuration.js");                                                                  // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"useraccounts-configuration.js":["meteor/accounts-base","../../api/projects/setup.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/useraccounts-configuration.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Accounts = void 0;                                                                                                 // 1
module.importSync("meteor/accounts-base", {                                                                            // 1
  Accounts: function (v) {                                                                                             // 1
    Accounts = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var initNewUser = void 0;                                                                                              // 1
module.importSync("../../api/projects/setup.js", {                                                                     // 1
  "default": function (v) {                                                                                            // 1
    initNewUser = v;                                                                                                   // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
// AccountsTemplates.configure({                                                                                       // 5
//   postSignUpHook: initNewUser,                                                                                      // 6
// })                                                                                                                  // 7
Accounts.onCreateUser(function (options, user) {                                                                       // 9
  initNewUser(user._id, options);                                                                                      // 10
  var localUser = user;                                                                                                // 11
                                                                                                                       //
  if (options.profile) {                                                                                               // 12
    localUser.profile = options.profile;                                                                               // 13
  }                                                                                                                    // 14
                                                                                                                       //
  return localUser;                                                                                                    // 15
});                                                                                                                    // 16
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"server":{"main.js":["../imports/startup/server/",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.importSync("../imports/startup/server/");                                                                       // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
